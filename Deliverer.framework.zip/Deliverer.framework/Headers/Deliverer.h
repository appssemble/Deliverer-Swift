//
//  Deliverer.h
//  Deliverer
//
//  Created by Dragos Dobrean on 10/01/2019.
//  Copyright © 2019 APPSSEMBLE-SOFT. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Deliverer.
FOUNDATION_EXPORT double DelivererVersionNumber;

//! Project version string for Deliverer.
FOUNDATION_EXPORT const unsigned char DelivererVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Deliverer/PublicHeader.h>



